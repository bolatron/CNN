load result.txt
d =    [2.8214e-27
       1.0000e+00
       2.7577e-33
       1.0000e+00
       1.0000e+00
       9.0850e-73
       4.7547e-11];
a = [0 0 0 0 0 0 1];
s = [0 0 0 0 0 1 0];
saida = ([[0 0 0 0 0 0 1]; [0 0 0 0 0 1 0]])';
disp(saida'(1, :));
disp(saida'(2, :));
[input_test, output_test] = test_db1();
error_test = 0;
for i=1:2
    [maxl, argma] = max(d');
    disp(argma);
    [maxs, argmaxs] = max(output_test(i, :));
    if argma != argmaxs
        error_test = error_test + 1;
    end
end
#for i=1:length (output_test)
#    [maxs, argmaxs] = max(output_test(i, :));
#end